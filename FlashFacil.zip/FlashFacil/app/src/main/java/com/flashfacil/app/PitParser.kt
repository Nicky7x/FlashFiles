package com.flashfacil.app

data class PitEntry(val id: String, val name: String, val flashFile: String)

/** Lê a saída de `heimdall print-pit` (mesma lógica do genFlashCommand.py do Nicky7x). */
object PitParser {
    fun parse(lines: List<String>): List<PitEntry> {
        val out = mutableListOf<PitEntry>()
        var id = ""; var name = ""
        for (raw in lines) {
            val l = raw.trim()
            when {
                l.startsWith("Identifier:") -> id = l.removePrefix("Identifier:").trim()
                l.startsWith("Partition Name:") -> name = l.removePrefix("Partition Name:").trim()
                l.startsWith("Flash Filename:") -> {
                    val f = l.removePrefix("Flash Filename:").trim()
                    if (name.isNotEmpty() && f.isNotEmpty() && f != "-") out += PitEntry(id, name, f)
                    name = ""
                }
            }
        }
        return out
    }
}
