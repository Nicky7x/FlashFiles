package com.flashfacil.app

import android.content.Context
import android.net.Uri
import net.jpountz.lz4.LZ4FrameInputStream
import java.io.File
import java.io.InputStream

/** Extrai .tar / .tar.md5 da Samsung (AP/BL/CP/CSC) e descompacta .lz4, sem ferramentas externas. */
object FirmwareExtractor {
    fun outDir(ctx: Context) = File(ctx.cacheDir, "cached_imgs").apply { mkdirs() }

    private fun readFully(i: InputStream, b: ByteArray): Int {
        var n = 0
        while (n < b.size) { val r = i.read(b, n, b.size - n); if (r < 0) break; n += r }
        return n
    }

    private fun parseSize(h: ByteArray): Long {
        if (h[124].toInt() and 0x80 != 0) { // base-256 para arquivos grandes
            var v = (h[124].toInt() and 0x7F).toLong()
            for (k in 125..135) v = (v shl 8) or (h[k].toLong() and 0xFF)
            return v
        }
        val s = String(h, 124, 12, Charsets.US_ASCII).trim { it == ' ' || it == '\u0000' }
        return if (s.isEmpty()) 0 else s.toLong(8)
    }

    /** Retorna os nomes dos arquivos extraídos. onProgress(arquivoAtual, bytesLidosDoTar). */
    fun extract(ctx: Context, uri: Uri, onProgress: (String, Long) -> Unit): List<String> {
        val dir = outDir(ctx)
        val result = mutableListOf<String>()
        val hdr = ByteArray(512)
        var total = 0L
        ctx.contentResolver.openInputStream(uri)!!.buffered(1 shl 20).use { inp ->
            while (true) {
                if (readFully(inp, hdr) < 512) break
                if (hdr.all { it.toInt() == 0 }) break               // fim do tar
                val name = String(hdr, 0, 100, Charsets.US_ASCII).trimEnd('\u0000')
                val type = hdr[156].toInt().toChar()
                val size = parseSize(hdr)
                val isFile = (type == '0' || type == '\u0000') && name.isNotEmpty() && !name.endsWith("/")
                val base = name.substringAfterLast('/')
                if (isFile && !base.endsWith(".md5") && size > 0) {
                    val outName = if (base.endsWith(".lz4")) base.removeSuffix(".lz4") else base
                    val outFile = File(dir, outName)
                    onProgress(outName, total)
                    val limited = Limited(inp, size)
                    val src: InputStream = if (base.endsWith(".lz4")) LZ4FrameInputStream(limited) else limited
                    outFile.outputStream().use { o -> src.copyTo(o, 1 shl 20) }
                    inp.skipFully(limited.left)   // consome o que sobrar da entrada, mantendo o tar alinhado
                    result += outName
                } else {
                    inp.skipFully(size)
                }
                total += size
                inp.skipFully((512 - size % 512) % 512)               // padding do bloco
            }
        }
        return result
    }

    private class Limited(private val inp: InputStream, var left: Long) : InputStream() {
        override fun read(): Int { if (left <= 0) return -1; val r = inp.read(); if (r >= 0) left--; return r }
        override fun read(b: ByteArray, o: Int, l: Int): Int {
            if (left <= 0) return -1
            val r = inp.read(b, o, minOf(l.toLong(), left).toInt()); if (r > 0) left -= r; return r
        }
    }

    private fun InputStream.skipFully(n: Long) {
        var left = n
        while (left > 0) {
            val s = skip(left)
            if (s <= 0) { if (read() < 0) return; left-- } else left -= s
        }
    }
}
