package com.flashfacil.app

/** Ponte JNI: fork/exec do Heimdall herdando o fd USB (ver cpp/spawn.c). */
object NativeSpawn {
    init { System.loadLibrary("flashnative") }
    /** Retorna [pid, fdDeLeitura] ou null se falhar. */
    external fun spawn(path: String, args: Array<String>, ldPath: String, usbFd: Int): IntArray?
    external fun waitFor(pid: Int): Int
    external fun kill(pid: Int)
}
