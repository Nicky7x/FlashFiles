package com.flashfacil.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private val Green = Color(0xFF4ADE80)
private val Red = Color(0xFFF87171)
private val Amber = Color(0xFFFBBF24)

class MainActivity : ComponentActivity() {
    private val vm: FlashViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 33)
            registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) {}
                .launch(android.Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFF8B7CF6), secondary = Color(0xFF2DD4BF),
                background = Color(0xFF0F1117), surface = Color(0xFF181B24), surfaceVariant = Color(0xFF222633)
            )) { App(vm) }
        }
    }
}

fun fmtTime(sec: Int?): String = if (sec == null) "--:--" else "%02d:%02d".format(sec / 60, sec % 60)
fun fmtSize(b: Long): String = if (b >= 1_048_576) "%.1f MB".format(b / 1_048_576.0) else "%d KB".format(b / 1024)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun App(vm: FlashViewModel) {
    val s by vm.state.collectAsStateWithLifecycle()
    val view = LocalView.current
    SideEffect { view.keepScreenOn = s.running }   // mantém a tela ligada durante o flash

    var pickIndex by remember { mutableIntStateOf(-1) }
    var confirm by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && pickIndex >= 0) FlashEngine.pickFile(pickIndex, uri)
    }
    val pkgPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) FlashEngine.extractPackages(uris)
    }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    val canFlash = s.items.any { it.ready } && !s.running && s.heimdallOk

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { TopAppBar(title = { Text("FlashFácil", fontWeight = FontWeight.Bold) },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)) }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 32.dp)) {

            if (!s.heimdallOk) item {
                InfoCard(Icons.Default.Warning, Amber, "Binário do Heimdall não encontrado",
                    "Coloque o executável compilado em app/src/main/jniLibs/<abi>/libheimdall.so e recompile.")
            }

            item { DeviceCard(s, onDetect = FlashEngine::detect) }

            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Firmware", style = MaterialTheme.typography.titleMedium)
                        Text("1) Leia o PIT do aparelho  2) Extraia AP/BL/CP/CSC  3) As partições são montadas sozinhas.",
                            style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(onClick = { FlashEngine.readPit() }, enabled = !s.running && !s.readingPit, modifier = Modifier.weight(1f)) {
                                if (s.readingPit) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp) else Icon(Icons.Default.Description, null, Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp)); Text("Ler PIT")
                            }
                            FilledTonalButton(onClick = { pkgPicker.launch(arrayOf("*/*")) }, enabled = !s.running && !s.extracting, modifier = Modifier.weight(1f)) {
                                if (s.extracting) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp) else Icon(Icons.Default.Archive, null, Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp)); Text("Extrair pacotes")
                            }
                        }
                        s.extractMsg?.let { Text(it, fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary) }
                        if (s.pit.isNotEmpty()) Text("PIT: ${s.pit.size} partições com arquivo de flash.", fontSize = 12.sp, color = Color.Gray)
                        Row {
                            TextButton(onClick = { FlashEngine.clearExtracted() }, enabled = !s.running) { Text("Apagar extraídos") }
                        }
                    }
                }
            }

            if (s.running || s.finished) item { ProgressCard(s, onCancel = FlashEngine::cancel) }

            if (s.finished) item {
                InfoCard(if (s.success) Icons.Default.CheckCircle else Icons.Default.Error,
                    if (s.success) Green else Red, if (s.success) "Tudo certo!" else "Algo deu errado", s.message ?: "")
            }

            item { Text("Arquivos para gravar", style = MaterialTheme.typography.titleMedium) }

            itemsIndexed(s.items) { i, it ->
                FileCard(it, enabled = !s.running, onPick = { pickIndex = i; picker.launch(arrayOf("*/*")) }, onRemove = { FlashEngine.removeItem(i) })
            }

            item {
                Text("Adicionar partição", style = MaterialTheme.typography.labelLarge, color = Color.Gray)
                Spacer(Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    vm.presets.forEach { p ->
                        AssistChip(onClick = { FlashEngine.addPartition(p) }, enabled = !s.running, label = { Text(p) },
                            leadingIcon = { Icon(Icons.Default.Add, null, Modifier.size(16.dp)) })
                    }
                }
            }

            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(16.dp)) {
                        SwitchRow("Não reiniciar ao terminar", "Útil para encadear gravações", s.noReboot, FlashEngine::setNoReboot, !s.running)
                    }
                }
            }

            if (s.items.any { it.ready }) item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Comando gerado", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                            TextButton(onClick = { clipboard.setText(androidx.compose.ui.text.AnnotatedString(FlashEngine.commandPreview(s))) }) { Text("Copiar") }
                        }
                        Text(FlashEngine.commandPreview(s), fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.LightGray)
                    }
                }
            }

            item {
                TextButton(onClick = {
                    ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        android.net.Uri.parse("package:" + ctx.packageName)))
                }) { Icon(Icons.Default.BatteryChargingFull, null); Spacer(Modifier.width(8.dp)); Text("Permitir rodar sem otimização de bateria") }
            }

            item {
                Button(onClick = { confirm = true }, enabled = canFlash, modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Default.FlashOn, null); Spacer(Modifier.width(8.dp))
                    Text("Iniciar flash", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            if (s.log.isNotEmpty()) item { LogCard(s.log) }
        }
    }

    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        icon = { Icon(Icons.Default.Warning, null, tint = Amber) },
        title = { Text("Confirmar flash?") },
        text = { Text("O aparelho precisa estar em Download Mode e conectado por cabo OTG. Não desconecte nem feche o app durante o processo. Gravar arquivos errados pode inutilizar o aparelho.") },
        confirmButton = { TextButton(onClick = { confirm = false; FlashEngine.start() }) { Text("Gravar") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancelar") } }
    )
}

@Composable
fun InfoCard(icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f))) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
            Icon(icon, null, tint = color); Spacer(Modifier.width(12.dp))
            Column { Text(title, fontWeight = FontWeight.SemiBold); Text(body, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable
fun DeviceCard(s: UiState, onDetect: () -> Unit) {
    val (color, text) = when (s.deviceFound) {
        true -> Green to "Aparelho detectado em Download Mode"
        false -> Red to "Nenhum aparelho encontrado"
        null -> Color.Gray to "Conecte por cabo OTG em Download Mode e toque em Detectar"
    }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Smartphone, null, tint = color, modifier = Modifier.size(36.dp))
            Spacer(Modifier.width(12.dp))
            Text(text, Modifier.weight(1f))
            if (s.detecting) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
            else FilledTonalButton(onClick = onDetect, enabled = !s.running) { Text("Detectar") }
        }
    }
}

@Composable
fun ProgressCard(s: UiState, onCancel: () -> Unit) {
    val stages = FlashStage.values()
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // Etapas
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                stages.forEach { st ->
                    val idx = st.ordinal; val cur = s.stage?.ordinal ?: -1
                    val c = when { s.finished && s.success -> Green; idx < cur -> Green; idx == cur -> MaterialTheme.colorScheme.primary; else -> Color.Gray }
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        Icon(if (idx < cur || (s.finished && s.success)) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked, null, tint = c)
                        Text(st.label, fontSize = 10.sp, color = c, maxLines = 2, lineHeight = 12.sp)
                    }
                }
            }
            Text(if (s.preparing) "Preparando arquivos…" else "Progresso total: ${s.overallPercent}%", fontWeight = FontWeight.SemiBold)
            LinearProgressIndicator(progress = { s.overallPercent / 100f }, modifier = Modifier.fillMaxWidth().height(10.dp), strokeCap = androidx.compose.ui.graphics.StrokeCap.Round)
            s.currentPartition?.let { Text("Gravando: $it", fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary) }
            // Métricas
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Metric("Velocidade", "%.1f MB/s".format(s.speedMbS))
                Metric("Decorrido", fmtTime(s.elapsedSec))
                Metric("Restante", fmtTime(s.etaSec))
            }
            if (s.running) OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Cancelar") }
        }
    }
}

@Composable
fun Metric(label: String, value: String) = Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(value, fontWeight = FontWeight.Bold, fontSize = 16.sp); Text(label, fontSize = 11.sp, color = Color.Gray)
}

@Composable
fun FileCard(item: FlashItem, enabled: Boolean, onPick: () -> Unit, onRemove: () -> Unit) {
    val statusColor = when (item.status) { ItemStatus.DONE -> Green; ItemStatus.FLASHING -> MaterialTheme.colorScheme.primary; else -> Color.Gray }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (item.status == ItemStatus.DONE) Icons.Default.CheckCircle else Icons.Default.Memory, null, tint = statusColor)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.partition, fontWeight = FontWeight.Bold)
                    Text(item.fileName?.let { "$it · ${fmtSize(item.size)}" } ?: "Nenhum arquivo selecionado",
                        style = MaterialTheme.typography.bodySmall, color = Color.Gray, maxLines = 1)
                }
                TextButton(onClick = onPick, enabled = enabled) { Text(if (!item.ready) "Escolher" else "Trocar") }
                IconButton(onClick = onRemove, enabled = enabled) { Icon(Icons.Default.Close, "Remover") }
            }
            if (item.status == ItemStatus.FLASHING) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(progress = { item.percent / 100f }, modifier = Modifier.fillMaxWidth())
                Text("${item.percent}%", fontSize = 11.sp, color = Color.Gray)
            }
        }
    }
}

@Composable
fun SwitchRow(title: String, sub: String, v: Boolean, onChange: (Boolean) -> Unit, enabled: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title); Text(sub, fontSize = 12.sp, color = Color.Gray) }
        Switch(checked = v, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
fun LogCard(log: List<String>) {
    var open by remember { mutableStateOf(false) }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("Log detalhado (${log.size})", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                TextButton(onClick = { open = !open }) { Text(if (open) "Ocultar" else "Mostrar") }
            }
            if (open) {
                val st = rememberLazyListState()
                LaunchedEffect(log.size) { st.scrollToItem(log.lastIndex) }
                LazyColumn(Modifier.heightIn(max = 260.dp), state = st) {
                    items(log) { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp,
                        color = if (it.startsWith("ERROR")) Red else Color.LightGray) }
                }
            }
        }
    }
}
