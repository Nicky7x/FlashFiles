package com.flashfacil.app

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.ContextCompat
import android.content.Intent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.File

data class FlashItem(
    val partition: String,
    val uri: Uri? = null,
    val file: File? = null,          // arquivo já extraído (não precisa copiar)
    val fileName: String? = null,
    val size: Long = 0,
    val status: ItemStatus = ItemStatus.WAITING,
    val percent: Int = 0
) { val ready get() = uri != null || file != null }

enum class ItemStatus { WAITING, FLASHING, DONE }

data class UiState(
    val heimdallOk: Boolean = true,
    val items: List<FlashItem> = emptyList(),
    val pit: List<PitEntry> = emptyList(),
    val readingPit: Boolean = false,
    val extracting: Boolean = false,
    val extractMsg: String? = null,
    val noReboot: Boolean = false,
    val detecting: Boolean = false,
    val deviceFound: Boolean? = null,
    val running: Boolean = false,
    val preparing: Boolean = false,
    val stage: FlashStage? = null,
    val currentPartition: String? = null,
    val overallPercent: Int = 0,
    val speedMbS: Float = 0f,
    val etaSec: Int? = null,
    val elapsedSec: Int = 0,
    val log: List<String> = emptyList(),
    val finished: Boolean = false,
    val success: Boolean = false,
    val message: String? = null
)

/**
 * Motor do flash. Vive no processo (não na Activity), então o flash continua
 * mesmo se a tela for fechada. O FlashService mantém o processo vivo em primeiro plano.
 */
object FlashEngine {
    private lateinit var app: Application
    private lateinit var runner: HeimdallRunner
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _state = MutableStateFlow(UiState())
    val state = _state.asStateFlow()
    private var job: Job? = null
    private var inited = false

    val presets = listOf("BOOT", "RECOVERY", "SYSTEM", "VENDOR", "DTBO", "VBMETA", "CACHE", "USERDATA")

    fun init(a: Application) {
        if (inited) return
        inited = true; app = a; runner = HeimdallRunner(a)
        _state.update { it.copy(heimdallOk = runner.available()) }
    }

    // ---------- edição da lista ----------
    fun addPartition(name: String) = _state.update { it.copy(items = it.items + FlashItem(name)) }
    fun removeItem(i: Int) = _state.update { it.copy(items = it.items.filterIndexed { idx, _ -> idx != i }) }
    fun setNoReboot(v: Boolean) = _state.update { it.copy(noReboot = v) }

    fun pickFile(i: Int, uri: Uri) {
        var name = "arquivo"; var size = 0L
        app.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                c.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { name = c.getString(it) }
                c.getColumnIndex(OpenableColumns.SIZE).takeIf { it >= 0 }?.let { size = c.getLong(it) }
            }
        }
        _state.update { s -> s.copy(items = s.items.mapIndexed { idx, it -> if (idx == i) it.copy(uri = uri, file = null, fileName = name, size = size) else it }) }
    }

    // ---------- detectar / PIT ----------
    fun detect() {
        scope.launch {
            _state.update { it.copy(detecting = true, deviceFound = null) }
            val found = UsbAccess.find(app) != null
            _state.update { it.copy(detecting = false, deviceFound = found) }
        }
    }

    fun readPit() {
        if (_state.value.running) return
        scope.launch {
            _state.update { it.copy(readingPit = true, message = null, finished = false) }
            val lines = mutableListOf<String>()
            var code = -1
            val conn = UsbAccess.open(app)
            if (conn == null) {
                _state.update { it.copy(readingPit = false, finished = true, success = false,
                    message = "Aparelho não encontrado ou permissão USB negada. Coloque em Download Mode, use cabo OTG e aceite a permissão.") }
                return@launch
            }
            try {
                runner.run(listOf("print-pit", "--no-reboot"), conn.fileDescriptor).collect { ev ->
                    if (ev is HeimdallEvent.Line) lines += ev.text
                    if (ev is HeimdallEvent.Exit) code = ev.code
                }
            } catch (e: Exception) { lines += "ERROR: ${e.message}" } finally { conn.close() }
            val pit = PitParser.parse(lines)
            _state.update {
                it.copy(readingPit = false, pit = pit, log = (it.log + lines).takeLast(500),
                    finished = pit.isEmpty(), success = false,
                    message = if (pit.isEmpty()) "Não consegui ler o PIT (código $code). Verifique o Download Mode e o cabo OTG." else null,
                    extractMsg = if (pit.isNotEmpty()) "PIT lido: ${pit.size} partições encontradas." else it.extractMsg)
            }
            if (pit.isNotEmpty()) matchExtracted()
        }
    }

    // ---------- extração de pacotes ----------
    fun extractPackages(uris: List<Uri>) {
        if (_state.value.running || uris.isEmpty()) return
        scope.launch {
            _state.update { it.copy(extracting = true, extractMsg = "Extraindo…", finished = false) }
            try {
                var count = 0
                withContext(Dispatchers.IO) {
                    uris.forEach { u ->
                        count += FirmwareExtractor.extract(app, u) { name, _ -> _state.update { it.copy(extractMsg = "Extraindo $name…") } }.size
                    }
                }
                _state.update { it.copy(extracting = false, extractMsg = "$count arquivos extraídos.") }
                matchExtracted()
            } catch (e: Exception) {
                _state.update { it.copy(extracting = false, extractMsg = null, finished = true, success = false,
                    message = "Falha ao extrair: ${e.message}. Verifique se há espaço livre suficiente.") }
            }
        }
    }

    fun clearExtracted() {
        FirmwareExtractor.outDir(app).deleteRecursively()
        _state.update { it.copy(items = it.items.filter { i -> i.file == null }, extractMsg = "Arquivos extraídos apagados.") }
    }

    /** Casa os arquivos extraídos com os "Flash Filename" do PIT e monta a lista (mesma ideia do genFlashCommand.py). */
    private fun matchExtracted() {
        val files = FirmwareExtractor.outDir(app).listFiles()?.filter { it.isFile } ?: return
        val pit = _state.value.pit
        if (pit.isEmpty()) {
            _state.update { it.copy(extractMsg = "Extraído. Toque em “Ler PIT” para mapear as partições automaticamente.") }
            return
        }
        val found = pit.mapNotNull { e -> files.firstOrNull { it.name.equals(e.flashFile, true) }?.let { e to it } }
            .distinctBy { it.first.name }
        _state.update { s ->
            val manual = s.items.filter { it.file == null }
            s.copy(items = manual + found.map { (e, f) -> FlashItem(e.name, file = f, fileName = f.name, size = f.length()) },
                extractMsg = "${found.size} partições prontas para gravar.")
        }
    }

    fun commandPreview(s: UiState): String {
        val parts = s.items.filter { it.ready }.joinToString(" ") { "--${it.partition} ${it.file?.path ?: it.fileName}" }
        return "heimdall flash $parts" + if (s.noReboot) " --no-reboot" else ""
    }

    // ---------- flash ----------
    fun start() {
        val st = _state.value
        val ready = st.items.filter { it.ready }
        if (ready.isEmpty() || st.running) return
        job = scope.launch {
            val conn = UsbAccess.open(app)
            if (conn == null) {
                finish(false, "Aparelho não encontrado ou permissão USB negada. Coloque em Download Mode, use cabo OTG e aceite a permissão.")
                return@launch
            }
            ContextCompat.startForegroundService(app, Intent(app, FlashService::class.java))
            _state.update {
                it.copy(running = true, preparing = true, finished = false, success = false, message = null,
                    log = emptyList(), overallPercent = 0, speedMbS = 0f, etaSec = null, elapsedSec = 0, stage = null,
                    currentPartition = null, items = it.items.map { i -> i.copy(status = ItemStatus.WAITING, percent = 0) })
            }
            val args = mutableListOf("flash")
            try {
                withContext(Dispatchers.IO) {
                    val dir = File(app.cacheDir, "flash").apply { deleteRecursively(); mkdirs() }
                    ready.forEach { item ->
                        val path = item.file?.path ?: File(dir, "${item.partition}.img").also { f ->
                            app.contentResolver.openInputStream(item.uri!!)!!.use { inp -> f.outputStream().use { inp.copyTo(it, 1 shl 20) } }
                        }.path
                        args += listOf("--${item.partition}", path)
                    }
                }
            } catch (e: Exception) { conn.close(); finish(false, "Falha ao preparar arquivos: ${e.message}"); return@launch }
            if (st.noReboot) args += "--no-reboot"
            _state.update { it.copy(preparing = false) }

            val total = ready.sumOf { it.size }.coerceAtLeast(1)
            var doneBytes = 0L; var curSize = 0L; var curName = ""; var t0 = 0L
            var error: String? = null
            try {
                runner.run(args, conn.fileDescriptor).collect { ev ->
                    when (ev) {
                        is HeimdallEvent.Line -> {
                            if (ev.text.startsWith("ERROR")) error = ev.text
                            _state.update { it.copy(log = (it.log + ev.text).takeLast(500)) }
                        }
                        is HeimdallEvent.Stage -> _state.update { it.copy(stage = ev.stage) }
                        is HeimdallEvent.PartitionStart -> {
                            if (t0 == 0L) t0 = System.currentTimeMillis()
                            curName = ev.name
                            curSize = ready.firstOrNull { it.partition.equals(ev.name, true) }?.size ?: 0
                            _state.update { it.copy(currentPartition = ev.name) }
                            setItem(ev.name) { it.copy(status = ItemStatus.FLASHING, percent = 0) }
                        }
                        is HeimdallEvent.Percent -> {
                            val bytes = doneBytes + curSize * ev.value / 100
                            val secs = ((System.currentTimeMillis() - t0) / 1000.0).coerceAtLeast(0.5)
                            val speed = (bytes / secs).toFloat()
                            setItem(curName) { it.copy(percent = ev.value) }
                            _state.update {
                                it.copy(overallPercent = (bytes * 100 / total).toInt().coerceIn(0, 100), speedMbS = speed / 1_048_576f,
                                    etaSec = if (speed > 0) ((total - bytes) / speed).toInt() else null, elapsedSec = secs.toInt())
                            }
                        }
                        is HeimdallEvent.PartitionDone -> { doneBytes += curSize; setItem(ev.name) { it.copy(status = ItemStatus.DONE, percent = 100) } }
                        is HeimdallEvent.Exit ->
                            if (ev.code == 0 && error == null) finish(true, "Flash concluído com sucesso!")
                            else finish(false, error ?: "O Heimdall terminou com erro (código ${ev.code}).")
                    }
                }
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) { finish(false, "Não foi possível executar o Heimdall: ${e.message}")
            } finally { conn.close() }
        }
    }

    fun cancel() {
        job?.cancel()
        finish(false, "Flash cancelado. Se foi interrompido no meio, o aparelho pode precisar de um novo flash completo.")
    }

    private fun setItem(name: String, f: (FlashItem) -> FlashItem) = _state.update { s ->
        s.copy(items = s.items.map { if (it.partition.equals(name, true)) f(it) else it })
    }

    private fun finish(ok: Boolean, msg: String) = _state.update {
        it.copy(running = false, preparing = false, finished = true, success = ok, message = msg,
            overallPercent = if (ok) 100 else it.overallPercent, etaSec = null)
    }
}
