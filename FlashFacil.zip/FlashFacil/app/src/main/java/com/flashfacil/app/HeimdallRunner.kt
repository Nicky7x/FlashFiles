package com.flashfacil.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.launch
import java.io.File

enum class FlashStage(val label: String) {
    DETECT("Detectando aparelho"),
    CONNECT("Conectando"),
    PIT("Lendo partições"),
    FLASH("Gravando"),
    FINISH("Finalizando")
}

sealed interface HeimdallEvent {
    data class Line(val text: String) : HeimdallEvent
    data class Stage(val stage: FlashStage) : HeimdallEvent
    data class PartitionStart(val name: String) : HeimdallEvent
    data class Percent(val value: Int) : HeimdallEvent
    data class PartitionDone(val name: String) : HeimdallEvent
    data class Exit(val code: Int) : HeimdallEvent
}

/** Converte a saída de texto do Heimdall em eventos estruturados. */
object HeimdallParser {
    private val percent = Regex("^(\\d{1,3})%$")
    private val uploading = Regex("^Uploading (.+)$")
    private val done = Regex("^(.+) upload successful$")

    fun parse(raw: String): List<HeimdallEvent> {
        val line = raw.trim()
        if (line.isEmpty()) return emptyList()
        val out = mutableListOf<HeimdallEvent>()
        percent.matchEntire(line)?.let { out += HeimdallEvent.Percent(it.groupValues[1].toInt().coerceIn(0, 100)); return out }
        out += HeimdallEvent.Line(line)
        when {
            line.startsWith("Detecting device") -> out += HeimdallEvent.Stage(FlashStage.DETECT)
            line.startsWith("Claiming") || line.startsWith("Setting up") || line.startsWith("Initialising") ||
                line.startsWith("Protocol initialisation") || line.startsWith("Beginning session") ||
                line.startsWith("Handshaking") || line.startsWith("Some devices") ->
                out += HeimdallEvent.Stage(FlashStage.CONNECT)
            line.contains("PIT file", ignoreCase = true) -> out += HeimdallEvent.Stage(FlashStage.PIT)
            line.startsWith("Ending session") || line.startsWith("Rebooting") || line.startsWith("Releasing") ->
                out += HeimdallEvent.Stage(FlashStage.FINISH)
            else -> {
                done.matchEntire(line)?.let { out += HeimdallEvent.PartitionDone(it.groupValues[1]) }
                    ?: uploading.matchEntire(line)?.let {
                        out += HeimdallEvent.Stage(FlashStage.FLASH)
                        out += HeimdallEvent.PartitionStart(it.groupValues[1])
                    }
            }
        }
        return out
    }
}

class HeimdallRunner(private val context: Context) {
    private val binary get() = File(context.applicationInfo.nativeLibraryDir, "libheimdall.so")
    fun available() = binary.exists()

    /** Executa o Heimdall (sem root) usando o file descriptor USB aberto pelo UsbManager. */
    fun run(args: List<String>, usbFd: Int): Flow<HeimdallEvent> = channelFlow {
        val res = NativeSpawn.spawn(binary.path, args.toTypedArray(), context.applicationInfo.nativeLibraryDir, usbFd)
            ?: throw IllegalStateException("não foi possível iniciar o processo do Heimdall")
        val pid = res[0]
        val finished = java.util.concurrent.atomic.AtomicBoolean(false)
        launch(Dispatchers.IO) {
            val pfd = android.os.ParcelFileDescriptor.adoptFd(res[1])
            val sb = StringBuilder()
            java.io.FileInputStream(pfd.fileDescriptor).bufferedReader().use { r ->
                while (true) {
                    val c = r.read()
                    if (c == -1) break
                    // O Heimdall atualiza o percentual com '\r', então dividimos por \r e \n
                    if (c == '\n'.code || c == '\r'.code) {
                        HeimdallParser.parse(sb.toString()).forEach { send(it) }
                        sb.clear()
                    } else sb.append(c.toChar())
                }
            }
            HeimdallParser.parse(sb.toString()).forEach { send(it) }
            val code = NativeSpawn.waitFor(pid)
            finished.set(true)
            send(HeimdallEvent.Exit(code))
            close()
        }
        awaitClose { if (!finished.get()) NativeSpawn.kill(pid) }
    }
}
