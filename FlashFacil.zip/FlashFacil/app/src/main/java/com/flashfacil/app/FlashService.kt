package com.flashfacil.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest

/** Serviço em primeiro plano: impede o Android de matar o processo durante o flash. */
class FlashService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) { FlashEngine.cancel(); return START_NOT_STICKY }
        createChannel()
        ServiceCompat.startForeground(this, ID, build("Preparando…", 0, true), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        wake = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FlashFacil:flash").apply { acquire(6 * 60 * 60 * 1000L) }
        scope.launch {
            FlashEngine.state.collectLatest { s ->
                if (!s.running && !s.preparing) { stopSelf(); return@collectLatest }
                val text = buildString {
                    append(s.stage?.label ?: "Preparando")
                    s.currentPartition?.let { append(" · $it") }
                    append(" · %.1f MB/s".format(s.speedMbS))
                    s.etaSec?.let { append(" · restam ${fmtTime(it)}") }
                }
                getSystemService(NotificationManager::class.java).notify(ID, build(text, s.overallPercent, s.preparing))
            }
        }
        return START_NOT_STICKY
    }

    private fun build(text: String, pct: Int, indeterminate: Boolean): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val cancel = PendingIntent.getService(this, 1, Intent(this, FlashService::class.java).setAction(ACTION_CANCEL), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("FlashFácil · $pct%")
            .setContentText(text)
            .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true)
            .setProgress(100, pct, indeterminate)
            .addAction(0, "Cancelar", cancel)
            .build()
    }

    private fun createChannel() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Flash em andamento", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onDestroy() { scope.cancel(); wake?.takeIf { it.isHeld }?.release(); super.onDestroy() }

    companion object { const val CH = "flash"; const val ID = 1; const val ACTION_CANCEL = "com.flashfacil.CANCEL" }
}
