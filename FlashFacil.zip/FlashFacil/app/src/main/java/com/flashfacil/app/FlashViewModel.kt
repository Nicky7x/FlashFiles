package com.flashfacil.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel

/** Fino: toda a lógica fica no FlashEngine, que sobrevive ao fechamento da tela. */
class FlashViewModel(app: Application) : AndroidViewModel(app) {
    init { FlashEngine.init(app) }
    val state = FlashEngine.state
    val presets = FlashEngine.presets
}
