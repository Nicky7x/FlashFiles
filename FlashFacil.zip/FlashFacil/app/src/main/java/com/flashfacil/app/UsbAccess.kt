package com.flashfacil.app

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** Acesso USB sem root: o próprio Android pede a permissão ao usuário e entrega o file descriptor. */
object UsbAccess {
    private const val ACTION = "com.flashfacil.USB_PERMISSION"
    private const val VID_SAMSUNG = 0x04E8
    // Mesmos PIDs que o Heimdall aceita (Download Mode)
    private val PIDS = setOf(0x6601, 0x685D, 0x68C3)

    fun find(ctx: Context): UsbDevice? =
        (ctx.getSystemService(Context.USB_SERVICE) as UsbManager).deviceList.values
            .firstOrNull { it.vendorId == VID_SAMSUNG && it.productId in PIDS }

    /** Pede permissão (se preciso) e abre o aparelho. Quem chama deve fechar a conexão ao terminar. */
    suspend fun open(ctx: Context): UsbDeviceConnection? {
        val mgr = ctx.getSystemService(Context.USB_SERVICE) as UsbManager
        val dev = find(ctx) ?: return null
        if (!mgr.hasPermission(dev) && !request(ctx, mgr, dev)) return null
        return mgr.openDevice(dev)
    }

    private suspend fun request(ctx: Context, mgr: UsbManager, dev: UsbDevice): Boolean =
        suspendCancellableCoroutine { cont ->
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    if (i.action != ACTION) return
                    try { ctx.unregisterReceiver(this) } catch (_: Exception) {}
                    if (cont.isActive) cont.resume(i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
                }
            }
            ContextCompat.registerReceiver(ctx, receiver, IntentFilter(ACTION), ContextCompat.RECEIVER_NOT_EXPORTED)
            val pi = PendingIntent.getBroadcast(ctx, 0, Intent(ACTION).setPackage(ctx.packageName), PendingIntent.FLAG_MUTABLE)
            mgr.requestPermission(dev, pi)
            cont.invokeOnCancellation { try { ctx.unregisterReceiver(receiver) } catch (_: Exception) {} }
        }
}
