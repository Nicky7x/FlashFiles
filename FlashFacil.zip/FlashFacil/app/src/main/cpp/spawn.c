// Executa o binário do Heimdall como processo filho herdando o fd USB aberto pelo UsbManager.
// (ProcessBuilder do Java fecha todos os fds > 2 no filho, por isso é preciso fork/exec nativo.)
#include <jni.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>

extern char **environ;

JNIEXPORT jintArray JNICALL
Java_com_flashfacil_app_NativeSpawn_spawn(JNIEnv *env, jobject thiz, jstring jpath, jobjectArray jargs,
                                          jstring jld, jint usbFd) {
    const char *path = (*env)->GetStringUTFChars(env, jpath, NULL);
    const char *ld = (*env)->GetStringUTFChars(env, jld, NULL);
    int n = (*env)->GetArrayLength(env, jargs);

    // Tudo que usa malloc é preparado ANTES do fork (o filho só pode usar funções async-signal-safe).
    char **argv = calloc(n + 2, sizeof(char *));
    argv[0] = strdup(path);
    for (int i = 0; i < n; i++) {
        jstring s = (jstring)(*env)->GetObjectArrayElement(env, jargs, i);
        const char *c = (*env)->GetStringUTFChars(env, s, NULL);
        argv[i + 1] = strdup(c);
        (*env)->ReleaseStringUTFChars(env, s, c);
        (*env)->DeleteLocalRef(env, s);
    }
    int ne = 0;
    while (environ && environ[ne]) ne++;
    char **envp = calloc(ne + 3, sizeof(char *));
    char b1[64], b2[1024];
    snprintf(b1, sizeof b1, "HEIMDALL_USB_FD=%d", (int)usbFd);
    snprintf(b2, sizeof b2, "LD_LIBRARY_PATH=%s", ld);
    envp[0] = strdup(b1);
    envp[1] = strdup(b2);
    for (int i = 0; i < ne; i++) envp[i + 2] = environ[i];

    int pfd[2];
    jintArray result = NULL;
    if (pipe(pfd) == 0) {
        pid_t pid = fork();
        if (pid == 0) {                      // filho
            dup2(pfd[1], 1);
            dup2(pfd[1], 2);
            close(pfd[0]);
            if (pfd[1] > 2) close(pfd[1]);
            fcntl(usbFd, F_SETFD, 0);        // garante que o fd USB sobreviva ao exec
            execve(argv[0], argv, envp);
            _exit(127);
        } else if (pid > 0) {                // pai
            close(pfd[1]);
            fcntl(pfd[0], F_SETFD, FD_CLOEXEC);
            jint out[2] = {(jint)pid, (jint)pfd[0]};
            result = (*env)->NewIntArray(env, 2);
            (*env)->SetIntArrayRegion(env, result, 0, 2, out);
        } else {
            close(pfd[0]); close(pfd[1]);
        }
    }
    for (int i = 0; argv[i]; i++) free(argv[i]);
    free(argv); free(envp[0]); free(envp[1]); free(envp);
    (*env)->ReleaseStringUTFChars(env, jpath, path);
    (*env)->ReleaseStringUTFChars(env, jld, ld);
    return result;
}

JNIEXPORT jint JNICALL
Java_com_flashfacil_app_NativeSpawn_waitFor(JNIEnv *env, jobject thiz, jint pid) {
    int st = 0;
    while (waitpid((pid_t)pid, &st, 0) < 0) { if (errno != EINTR) break; }
    if (WIFEXITED(st)) return WEXITSTATUS(st);
    if (WIFSIGNALED(st)) return 128 + WTERMSIG(st);
    return -1;
}

JNIEXPORT void JNICALL
Java_com_flashfacil_app_NativeSpawn_kill(JNIEnv *env, jobject thiz, jint pid) {
    kill((pid_t)pid, SIGTERM);
}
