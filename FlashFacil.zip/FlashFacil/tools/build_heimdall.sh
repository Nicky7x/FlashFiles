#!/usr/bin/env bash
# Compila o Heimdall (patchado) para Android arm64 e instala como libheimdall.so no jniLibs.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NDK="${ANDROID_NDK_LATEST_HOME:-${ANDROID_NDK_ROOT:-${ANDROID_NDK_HOME:-}}}"
[ -d "$NDK" ] || { echo "NDK não encontrado"; exit 1; }
API=26; ABI=arm64-v8a
TOOL="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin"
CC="$TOOL/aarch64-linux-android${API}-clang"; AR="$TOOL/llvm-ar"
W="$ROOT/.native-build"; mkdir -p "$W"; cd "$W"

[ -d libusb ]  || git clone --depth 1 --branch v1.0.27 https://github.com/libusb/libusb.git
[ -d Heimdall ] || git clone --depth 1 https://github.com/Benjamin-Dobell/Heimdall.git

echo "== libusb (estático) =="
cd libusb; mkdir -p obj
for f in libusb/core.c libusb/descriptor.c libusb/hotplug.c libusb/io.c libusb/strerror.c libusb/sync.c \
         libusb/os/events_posix.c libusb/os/threads_posix.c libusb/os/linux_usbfs.c libusb/os/linux_netlink.c; do
  "$CC" -c -O2 -fPIC -I android -I libusb -I libusb/os "$f" -o "obj/$(basename "$f" .c).o"
done
"$AR" rcs libusb1.0.a obj/*.o
LIBUSB="$PWD"; cd ..

echo "== Heimdall =="
cd Heimdall
python3 "$ROOT/tools/patch_heimdall.py" .
cmake -S . -B build-android -G "Unix Makefiles" \
  -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=$ABI -DANDROID_PLATFORM=android-$API -DCMAKE_BUILD_TYPE=Release \
  -DDISABLE_FRONTEND=ON \
  -DLIBUSB_LIBRARY="$LIBUSB/libusb1.0.a" -DLIBUSB_LIBRARIES="$LIBUSB/libusb1.0.a" \
  -DLIBUSB_INCLUDE_DIR="$LIBUSB/libusb" -DLIBUSB_INCLUDE_DIRS="$LIBUSB/libusb" \
  -DCMAKE_CXX_FLAGS="-I$LIBUSB/libusb -DOS_LINUX" -DCMAKE_EXE_LINKER_FLAGS="-llog"
cmake --build build-android --target heimdall -j"$(nproc)"

OUT="$ROOT/app/src/main/jniLibs/$ABI"; mkdir -p "$OUT"
BIN="$(find build-android -type f -name heimdall -perm -u+x | head -n1)"
cp "$BIN" "$OUT/libheimdall.so"
file "$OUT/libheimdall.so" || true
echo "OK: $OUT/libheimdall.so"
