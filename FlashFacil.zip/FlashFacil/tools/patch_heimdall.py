#!/usr/bin/env python3
"""Aplica no código do Heimdall o suporte a abrir o USB por file descriptor (Android sem root).
Uso: patch_heimdall.py <pasta do Heimdall>"""
import re, sys, pathlib
root = pathlib.Path(sys.argv[1])

# --- BridgeManager.cpp: troca init/lista/open do libusb por wrappers que entendem HEIMDALL_USB_FD ---
p = root / "heimdall/source/BridgeManager.cpp"
s = p.read_text()
assert "#include <libusb.h>" in s, "include do libusb não encontrado"
WRAP = r'''#include <libusb.h>
#include <cstdlib>

// ===== FlashFacil: acesso USB sem root via fd entregue pelo Android UsbManager =====
static libusb_device_handle *hd_wrapped_handle = nullptr;

static int hd_usb_fd(void)
{
	const char *e = getenv("HEIMDALL_USB_FD");
	return e ? atoi(e) : -1;
}

static int hd_init(libusb_context **ctx)
{
	if (hd_usb_fd() >= 0)
		libusb_set_option(NULL, LIBUSB_OPTION_NO_DEVICE_DISCOVERY);   // não enumerar /dev/bus/usb
	return libusb_init(ctx);
}

static ssize_t hd_get_device_list(libusb_context *ctx, libusb_device ***list)
{
	int fd = hd_usb_fd();
	if (fd < 0)
		return libusb_get_device_list(ctx, list);

	if (!hd_wrapped_handle)
	{
		int r = libusb_wrap_sys_device(ctx, (intptr_t)fd, &hd_wrapped_handle);
		if (r != LIBUSB_SUCCESS)
		{
			*list = (libusb_device **)calloc(1, sizeof(libusb_device *));
			return 0;
		}
		libusb_set_auto_detach_kernel_driver(hd_wrapped_handle, 1);
	}
	libusb_device *dev = libusb_get_device(hd_wrapped_handle);
	libusb_ref_device(dev);
	*list = (libusb_device **)calloc(2, sizeof(libusb_device *));
	(*list)[0] = dev;
	return 1;
}

static void hd_free_device_list(libusb_device **list, int unref)
{
	if (hd_usb_fd() < 0)
	{
		libusb_free_device_list(list, unref);
		return;
	}
	if (unref && list && list[0])
		libusb_unref_device(list[0]);
	free(list);
}

static int hd_open(libusb_device *dev, libusb_device_handle **handle)
{
	if (hd_usb_fd() >= 0 && hd_wrapped_handle && libusb_get_device(hd_wrapped_handle) == dev)
	{
		*handle = hd_wrapped_handle;
		return LIBUSB_SUCCESS;
	}
	return libusb_open(dev, handle);
}

#define libusb_init hd_init
#define libusb_get_device_list hd_get_device_list
#define libusb_free_device_list hd_free_device_list
#define libusb_open hd_open
// ===== fim FlashFacil ====='''
s = s.replace("#include <libusb.h>", WRAP, 1)
p.write_text(s)

# --- main.cpp: stdout sem buffer, para o app receber o progresso em tempo real pelo pipe ---
m = root / "heimdall/source/main.cpp"
t = m.read_text()
t2, n = re.subn(r'(int\s+main\s*\([^)]*\)\s*\{)', r'\1\n\tsetvbuf(stdout, NULL, _IONBF, 0);\n\tsetvbuf(stderr, NULL, _IONBF, 0);', t, count=1)
assert n == 1, "main() não encontrado em main.cpp"
m.write_text(t2)
print("Patch aplicado.")
