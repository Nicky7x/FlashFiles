# FlashFácil v0.3 — sem root

Alternativa ao Heimdoo com interface amigável, PIT, extração de pacotes e flash em serviço de primeiro plano.

## Como funciona sem root
1. `UsbAccess` pede ao Android a permissão USB e abre o aparelho (`UsbManager.openDevice`) → obtém um *file descriptor*.
2. `cpp/spawn.c` (JNI) faz `fork/exec` do Heimdall herdando esse fd (o `ProcessBuilder` do Java fecharia o fd) e captura a saída.
3. O Heimdall é compilado a partir do código oficial com um patch (`tools/patch_heimdall.py`): se existir `HEIMDALL_USB_FD`,
   usa `libusb_wrap_sys_device()` em vez de enumerar `/dev/bus/usb` (que exige root). Mesma ideia do Heimdoo.

## Compilar (GitHub Actions, funciona pelo celular)
O workflow `.github/workflows/build.yml` compila libusb 1.0.27 + Heimdall (arm64) com o NDK, instala em
`jniLibs/arm64-v8a/libheimdall.so` e gera o APK. Actions → *Build APK* → *Run workflow* → baixe `FlashFacil-debug-apk`.

## Recursos
Ler PIT · Extrair AP/BL/CP/CSC (.tar/.tar.md5/.lz4) e mapear pelo PIT · comando gerado · progresso/velocidade/ETA ·
serviço em primeiro plano + WakeLock + notificação com Cancelar · log completo.

## Avisos
- Nunca testado em aparelho real; o build nativo nunca rodou. Se o Actions falhar, o log do passo "Compilar Heimdall nativo" mostra o erro.
- Só arm64-v8a. MD5 do .tar.md5 não é verificado. Use HOME_CSC para preservar dados (CSC apaga tudo).
- Gravar firmware errado pode inutilizar o aparelho. Use por sua conta e risco.
